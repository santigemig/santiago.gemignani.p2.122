
package config;


public interface CSVSerializable {
    String toCSV();
    
}
