
package persistence;

import config.CSVSerializable;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public interface Persistence {
    
    static <T extends Serializable> void guardarEnArchivo(List<T> lista, String ruta)
              throws IOException {   
    
        
       try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
     }
   }      
       

    static <T extends Serializable> List<T> cargarDesdeArchivo(String ruta)
            throws IOException, ClassNotFoundException {
    
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            @SuppressWarnings("unchecked")
            List<T> lista = (List<T>) ois.readObject();
            return lista;        
        
        }   
    }

    static <T extends CSVSerializable> void guardarEnCSV(List<T> lista, String ruta)
            throws IOException {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (T elem : lista) {
                bw.write(elem.toCSV());
                bw.newLine();

            }
        }
    }

    static <T> List<T> cargarDesdeCSV(String ruta, Function<String, T> mapper)
            throws IOException {
        
        List<T> resultado = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.isBlank()) {
                    resultado.add(mapper.apply(linea));        
                }
            }
        }
        return resultado;
    }
}