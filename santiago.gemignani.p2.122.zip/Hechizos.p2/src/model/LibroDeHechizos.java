
package model;
import config.CSVSerializable;
import persistence.Persistence;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LibroDeHechizos <T extends CSVSerializable & Serializable> implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    private final List<T> inventario = new ArrayList<>();


    public void agregar(T elemento){
        inventario.add(elemento);
}
     public T obtener(int indice) {
      return inventario.get(indice);

}
     public T eliminar(int indice) {
        return inventario.remove(indice);
}

     public void paraCadaElemento(Consumer<T> accion) {
        inventario.forEach(accion);
}
     public List<T> filtrar (Predicate<T> criterio){
        List<T> resultado = new ArrayList<>();
        for (T elem : inventario) {
            if (criterio.test(elem)) {
                resultado.add(elem);
            }
        }
        return resultado;
}

     public void ordenar(Comparator<T> comparator) {
        inventario.sort(comparator);     
     
}   
     public void guardarEnArchivo(String ruta) throws IOException {
       Persistence.guardarEnArchivo(inventario, ruta);
    }
    
     public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
       List<T> cargados = Persistence.cargarDesdeArchivo(ruta);
       inventario.clear();
       inventario.addAll(cargados);
    }     
     
     public void guardarEnCSV(String ruta) throws IOException {
       Persistence.guardarEnCSV(inventario, ruta);     
    }
     
    public void cargarDesdeCSV(String ruta, Function<String, T> mapper) throws IOException {
        List<T> cargados = Persistence.cargarDesdeCSV(ruta, mapper);
        inventario.clear();
        inventario.addAll(cargados);
    }     
     
}
