
package model;

import config.CSVSerializable;
import java.io.Serializable;


public class Hechizo implements CSVSerializable , Comparable<Hechizo> , Serializable {
    
    private static final long serialVersionUID = 1L;
    
    
    private int id;
    private String nombre;
    private String creador;
    private TipoHechizo tipo;

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipo() {
        return tipo;
    }
   
    
    @Override
    public int compareTo(Hechizo otro){
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toString() {
        return "Hechizo{" + "id=" + id + ", nombre=" + nombre + ", creador=" + creador + ", tipo=" + tipo + '}';
    }
    
    @Override
    public String toCSV(){
       return id + "," + nombre + "," + creador + "," + tipo.name();
    }
    
    public static Hechizo fromCSV(String linea){
        String[] partes = linea.split(",");
        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        String creador = partes[2];
        TipoHechizo tipo = TipoHechizo.valueOf(partes[3]);
        return new Hechizo(id, nombre, creador, tipo);
    }
    
    
}
